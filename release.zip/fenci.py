#!/usr/bin/env python
# -*- coding: utf-8 -*-
import jieba

def mypy():
    print("this is py_print")
    a = ["123","456","789"]
    return a

def jiebacutlist(str):
    print("this is py_print")

#    print(str)
#    str = "我来自"
    words = jieba.lcut(str)
    counts = {}
    num = 0

    Punctuation_List = ['《','》','，','。','？','/','：','；','“','’','{','}','【','】','（','）','了']

    for word in words:
        if word in Punctuation_List:
            continue
#        elif len(word) == 1:
#            continue
        else:
            counts[word] = counts.get(word,0) + 1
            num = num + 1

    print('[python]num:',num)

    return counts
